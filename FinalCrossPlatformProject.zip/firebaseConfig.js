// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyCVbBvdSju-4r1SX_t7E2ctir92I18_vgc",
  authDomain: "cross-final.firebaseapp.com",
  projectId: "cross-final",
  storageBucket: "cross-final.appspot.com",
  messagingSenderId: "75948828751",
  appId: "1:75948828751:web:83d188da744b9ea534223a",
  measurementId: "G-11MJEXGTD5"
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);