import { StyleSheet } from 'react-native';

export default StyleSheet.create({
  text: {
    fontSize: 23,
    fontWeight: 'bold',
    marginTop: 45,
    marginLeft: 25,
    marginBottom: 10,
  },
  flatListContent: {
    paddingBottom: 20,
    marginLeft: 8,
  },
});